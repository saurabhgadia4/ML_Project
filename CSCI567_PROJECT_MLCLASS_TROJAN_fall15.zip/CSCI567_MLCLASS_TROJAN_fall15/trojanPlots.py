class Plots:
	def __init__(self, dflist, plotList):
		self.dflist = dflist

	def driver(self):


#Histogram plotting
#df['Ref'].plot(kind='hist')